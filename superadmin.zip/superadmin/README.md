# superadmin
Steam ids admin menü
steam id-det beirod és az F11-el elő tudod hozni